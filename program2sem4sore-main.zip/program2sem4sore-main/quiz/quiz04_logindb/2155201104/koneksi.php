<?php
$conn = mysqli_connect('localhost', 'root', '', 'program2');
