<?php
$_SERVER ="localhost";
$user ="root";
$pass ="";
$database ="latihan";
$koneksi = mysqli_connect('localhost', 'root', '', 'quiz');

?> 