<?php

$koneksi = mysqli_connect('127.0.0.1', 'root', '', 'belajar', '3306');