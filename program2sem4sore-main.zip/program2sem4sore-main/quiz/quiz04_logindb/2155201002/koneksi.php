<?php 
$server = "localhost";
$user   ="root";
$pass ="";
$database ="db";

$conn = mysqli_connect($server,$user,$pass,$database);

?>