<?php

$conn = mysqli_connect('localhost', 'root', '', 'nama_database');