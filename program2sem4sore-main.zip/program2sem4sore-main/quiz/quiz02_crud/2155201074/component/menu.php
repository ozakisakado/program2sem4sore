<ul>
    <li>
        <a href="index.php">Form Input</a>
        <a href="data.php">Data</a>
    </li>
</ul>